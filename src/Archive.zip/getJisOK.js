export function getJisOK(color) {
    return ("grey");
  }